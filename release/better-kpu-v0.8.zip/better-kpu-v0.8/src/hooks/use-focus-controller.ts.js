export function useFocusController() {
  const handleFocus = () => {
  };
  return {
    handleFocus
  };
}
