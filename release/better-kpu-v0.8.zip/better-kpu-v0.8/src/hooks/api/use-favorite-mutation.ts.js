import kpuApi from "/src/lib/kpu-api/index.ts.js";
import { useMutation, useQueryClient } from "/vendor/.vite-deps-@tanstack_react-query.js__v--752ceaf0.js";
export function useFavoriteMutation() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ favorite, uid }) => kpuApi.updateFavorite({ favorite, uid }),
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: ["services"]
      });
      queryClient.invalidateQueries({
        queryKey: ["other-services"]
      });
    }
  });
}
