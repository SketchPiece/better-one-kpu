import kpuApi from "/src/lib/kpu-api/index.ts.js";
import { useQuery } from "/vendor/.vite-deps-@tanstack_react-query.js__v--752ceaf0.js";
export function useNotificationsQuery() {
  return useQuery({
    queryKey: ["notifications"],
    queryFn: () => kpuApi.getNotifications()
  });
}
