import kpuApi from "/src/lib/kpu-api/index.ts.js";
import { useQuery } from "/vendor/.vite-deps-@tanstack_react-query.js__v--b8b6b26c.js";
export function useUserProfile() {
  return useQuery({
    queryKey: ["profile"],
    queryFn: () => kpuApi.getUserProfile()
  });
}
