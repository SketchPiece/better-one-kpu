import kpuApi from "/src/lib/kpu-api/index.ts.js";
import { useQuery } from "/vendor/.vite-deps-@tanstack_react-query.js__v--752ceaf0.js";
import { usePreferences } from "/src/hooks/use-preferences.ts.js";
function defineServices(key, services) {
  if (key === "essentials")
    return services?.essentials;
  else if (key === "favorites")
    return services?.favorites;
  else if (key === "recents")
    return services?.recents;
  return void 0;
}
export function useQuickServices({ quickFilter }) {
  const { preferences } = usePreferences();
  const { data: services, ...rest } = useQuery({
    queryKey: ["services", preferences.roles.sort().join(",")],
    queryFn: () => kpuApi.getQuickServices({ roles: preferences.roles })
  });
  const quickServices = defineServices(quickFilter, services);
  const quickServicesIds = quickServices?.map(({ id }) => id) || [];
  return {
    data: quickServices,
    dataIds: quickServicesIds,
    ...rest
  };
}
