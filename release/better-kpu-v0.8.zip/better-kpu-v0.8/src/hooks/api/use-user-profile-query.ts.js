import kpuApi from "/src/lib/kpu-api/index.ts.js";
import { useQuery } from "/vendor/.vite-deps-@tanstack_react-query.js__v--752ceaf0.js";
function refineUser(profile) {
  if (!profile)
    return null;
  if (profile.email === "andrii.liubkin@student.kpu.ca")
    return { ...profile, greetingName: "Andrew", username: "Andrew Liubkin" };
  return profile;
}
export function useUserProfileQuery() {
  const { data, ...rest } = useQuery({
    queryKey: ["profile"],
    queryFn: () => kpuApi.getUserProfile()
  });
  return {
    data: refineUser(data),
    ...rest
  };
}
