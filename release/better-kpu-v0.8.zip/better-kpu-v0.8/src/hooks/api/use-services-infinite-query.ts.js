import kpuApi from "/src/lib/kpu-api/index.ts.js";
import { useInfiniteQuery } from "/vendor/.vite-deps-@tanstack_react-query.js__v--752ceaf0.js";
import { usePreferences } from "/src/hooks/use-preferences.ts.js";
export function useServicesInfiniteQuery({
  searchQuery,
  category
}) {
  const { preferences } = usePreferences();
  const { data, fetchNextPage, hasNextPage, ...rest } = useInfiniteQuery({
    queryKey: [
      "services",
      searchQuery,
      category,
      preferences.roles.sort().join(",")
    ],
    queryFn: ({ pageParam }) => kpuApi.getAllServices({
      pageNumber: pageParam,
      searchQuery,
      category,
      roles: preferences.roles
    }),
    initialPageParam: 0,
    getNextPageParam: (lastPage) => lastPage.hasNextPage ? lastPage.page + 1 : null
  });
  const flatPagesData = data?.pages.flatMap((page) => page.data);
  return {
    data: flatPagesData,
    fetchNextPage,
    hasNextPage,
    ...rest
  };
}
