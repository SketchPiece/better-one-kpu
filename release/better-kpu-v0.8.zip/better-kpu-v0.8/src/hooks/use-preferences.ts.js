import { useLocalStorage } from "/vendor/.vite-deps-@mantine_hooks.js__v--752ceaf0.js";
import { z } from "/vendor/.vite-deps-zod.js__v--752ceaf0.js";
const preferencesSchema = z.object({
  defaultView: z.enum(["essentials", "favorites", "recents"]),
  roles: z.array(z.enum(["student", "employee"]))
});
const defaultPreferences = {
  defaultView: "essentials",
  roles: ["student", "employee"]
};
export function usePreferences() {
  const [preferences, setPreferences] = useLocalStorage({
    key: "better-kpu-preferences",
    defaultValue: defaultPreferences,
    getInitialValueInEffect: false
  });
  const validatedPreferences = preferencesSchema.safeParse(preferences);
  if (!validatedPreferences.success)
    setPreferences(defaultPreferences);
  const updatePreference = (key, value) => {
    setPreferences((prev) => ({ ...prev, [key]: value }));
  };
  return { preferences, updatePreference };
}
