import { createHotContext as __vite__createHotContext } from "/vendor/vite-client.js";import.meta.hot = __vite__createHotContext("/src/pages/home.tsx.js");import __vite__cjsImport0_react_jsxDevRuntime from "/vendor/.vite-deps-react_jsx-dev-runtime.js__v--752ceaf0.js"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/vendor/react-refresh.js";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/pages/home.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import Header from "/src/components/header/index.ts.js";
import { Separator } from "/src/components/ui/separator.tsx.js";
import CategoriesFilterDialog from "/src/components/home/categories-filter-dialog.tsx.js";
import QuickFilters from "/src/components/home/quick-filters.tsx.js";
import Greeting from "/src/components/home/greeting.tsx.js";
import QuickServices from "/src/components/home/quick-services.tsx.js";
import OtherServices from "/src/components/home/other-services.tsx.js";
import { usePreferences } from "/src/hooks/use-preferences.ts.js";
import useFilterState from "/src/components/home/hooks/use-filter-state.ts.js";
import { useUserProfileQuery } from "/src/hooks/api/use-user-profile-query.ts.js";
import { useDebouncedValue } from "/vendor/.vite-deps-@mantine_hooks.js__v--752ceaf0.js";
import ScrollToTopButton from "/src/components/scroll-to-top-button.tsx.js";
export default function Home() {
  _s();
  const { data: userProfile } = useUserProfileQuery();
  const {
    preferences: { defaultView }
  } = usePreferences();
  const {
    state,
    handleQuickFilterChange,
    handleCategoryChange,
    handleSearchQueryChange
  } = useFilterState({ defaultQuickFilter: defaultView });
  const [debouncedSearchQuery] = useDebouncedValue(state.searchQuery, 500);
  const showQuickServices = state.selectedQuickFilter !== null;
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV(
      Header,
      {
        searchQuery: state.searchQuery,
        onSearchQueryChange: handleSearchQueryChange
      },
      void 0,
      false,
      {
        fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/pages/home.tsx",
        lineNumber: 33,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("main", { className: "mt-8 px-6", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between", children: [
        /* @__PURE__ */ jsxDEV(Greeting, { name: userProfile?.greetingName }, void 0, false, {
          fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/pages/home.tsx",
          lineNumber: 39,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4", children: [
          /* @__PURE__ */ jsxDEV(
            QuickFilters,
            {
              value: state.selectedQuickFilter,
              onChange: handleQuickFilterChange,
              authorized: Boolean(userProfile)
            },
            void 0,
            false,
            {
              fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/pages/home.tsx",
              lineNumber: 41,
              columnNumber: 13
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(Separator, { orientation: "vertical", className: "h-8" }, void 0, false, {
            fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/pages/home.tsx",
            lineNumber: 46,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(
            CategoriesFilterDialog,
            {
              value: state.selectedCategory,
              onChange: handleCategoryChange
            },
            void 0,
            false,
            {
              fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/pages/home.tsx",
              lineNumber: 47,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/pages/home.tsx",
          lineNumber: 40,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/pages/home.tsx",
        lineNumber: 38,
        columnNumber: 9
      }, this),
      showQuickServices && /* @__PURE__ */ jsxDEV(QuickServices, { filter: state.selectedQuickFilter }, void 0, false, {
        fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/pages/home.tsx",
        lineNumber: 54,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        OtherServices,
        {
          searchQuery: debouncedSearchQuery,
          category: state.selectedCategory,
          quickFilter: state.selectedQuickFilter
        },
        void 0,
        false,
        {
          fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/pages/home.tsx",
          lineNumber: 56,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/pages/home.tsx",
      lineNumber: 37,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(ScrollToTopButton, {}, void 0, false, {
      fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/pages/home.tsx",
      lineNumber: 62,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/pages/home.tsx",
    lineNumber: 32,
    columnNumber: 5
  }, this);
}
_s(Home, "VtJrMFkSIXpCXjphL585dquBDN4=", false, function() {
  return [useUserProfileQuery, usePreferences, useFilterState, useDebouncedValue];
});
_c = Home;
var _c;
$RefreshReg$(_c, "Home");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/pages/home.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
