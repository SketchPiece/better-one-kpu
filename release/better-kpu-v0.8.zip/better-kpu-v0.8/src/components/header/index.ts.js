export { default } from "/src/components/header/header.tsx.js";
