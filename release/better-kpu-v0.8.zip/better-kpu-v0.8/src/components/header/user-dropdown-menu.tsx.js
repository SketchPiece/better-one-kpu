import { createHotContext as __vite__createHotContext } from "/vendor/vite-client.js";import.meta.hot = __vite__createHotContext("/src/components/header/user-dropdown-menu.tsx.js");import __vite__cjsImport0_react_jsxDevRuntime from "/vendor/.vite-deps-react_jsx-dev-runtime.js__v--752ceaf0.js"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/vendor/react-refresh.js";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header/user-dropdown-menu.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { usePreferences } from "/src/hooks/use-preferences.ts.js";
import { Icons } from "/src/components/icons.tsx.js";
import { Avatar, AvatarFallback } from "/src/components/ui/avatar.tsx.js";
import {
  DropdownMenu,
  DropdownMenuCheckboxItem,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuPortal,
  DropdownMenuRadioGroup,
  DropdownMenuRadioItem,
  DropdownMenuSeparator,
  DropdownMenuSub,
  DropdownMenuSubContent,
  DropdownMenuSubTrigger,
  DropdownMenuTrigger
} from "/src/components/ui/dropdown-menu.tsx.js";
import SimpleTooltip from "/src/components/ui/simple-tooltip.tsx.js";
import { useClipboard } from "/vendor/.vite-deps-@mantine_hooks.js__v--752ceaf0.js";
function includeValue(array, value) {
  if (array.includes(value)) {
    return [...array];
  }
  return [...array, value];
}
function excludeValue(array, value) {
  return array.filter((item) => item !== value);
}
export default function UserDropdownMenu({
  initials,
  username,
  email,
  onSignOut
}) {
  _s();
  const { preferences, updatePreference } = usePreferences();
  const clipboard = useClipboard({ timeout: 2e3 });
  const handleRoleCheckboxChange = (role, checked) => {
    updatePreference(
      "roles",
      checked ? includeValue(preferences.roles, role) : excludeValue(preferences.roles, role)
    );
  };
  const copyEmailContent = clipboard.copied ? "Copied to your clipboard" : "Click to copy email address";
  return /* @__PURE__ */ jsxDEV(DropdownMenu, { children: [
    /* @__PURE__ */ jsxDEV(DropdownMenuTrigger, { asChild: true, children: /* @__PURE__ */ jsxDEV("button", { className: "dark:ring-offset-dark-background rounded-full transition-all focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2", children: /* @__PURE__ */ jsxDEV(Avatar, { children: /* @__PURE__ */ jsxDEV(AvatarFallback, { children: initials }, void 0, false, {
      fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header/user-dropdown-menu.tsx",
      lineNumber: 71,
      columnNumber: 13
    }, this) }, void 0, false, {
      fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header/user-dropdown-menu.tsx",
      lineNumber: 70,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header/user-dropdown-menu.tsx",
      lineNumber: 69,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header/user-dropdown-menu.tsx",
      lineNumber: 68,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(DropdownMenuContent, { align: "end", children: [
      /* @__PURE__ */ jsxDEV(DropdownMenuLabel, { className: "flex flex-col", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "font-medium", children: username }, void 0, false, {
          fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header/user-dropdown-menu.tsx",
          lineNumber: 77,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          SimpleTooltip,
          {
            content: copyEmailContent,
            side: "bottom",
            open: clipboard.copied ? true : void 0,
            children: /* @__PURE__ */ jsxDEV("button", { onClick: () => clipboard.copy(email), className: "text-sm", children: email }, void 0, false, {
              fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header/user-dropdown-menu.tsx",
              lineNumber: 83,
              columnNumber: 13
            }, this)
          },
          void 0,
          false,
          {
            fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header/user-dropdown-menu.tsx",
            lineNumber: 78,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header/user-dropdown-menu.tsx",
        lineNumber: 76,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(DropdownMenuSeparator, {}, void 0, false, {
        fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header/user-dropdown-menu.tsx",
        lineNumber: 88,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(DropdownMenuSub, { children: [
        /* @__PURE__ */ jsxDEV(DropdownMenuSubTrigger, { children: [
          /* @__PURE__ */ jsxDEV(Icons.eye, { className: "mr-2" }, void 0, false, {
            fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header/user-dropdown-menu.tsx",
            lineNumber: 91,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("span", { children: "Default View" }, void 0, false, {
            fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header/user-dropdown-menu.tsx",
            lineNumber: 92,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header/user-dropdown-menu.tsx",
          lineNumber: 90,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(DropdownMenuPortal, { children: /* @__PURE__ */ jsxDEV(DropdownMenuSubContent, { children: [
          /* @__PURE__ */ jsxDEV(DropdownMenuLabel, { className: "px-3 py-2.5 font-medium", children: "Select Default View" }, void 0, false, {
            fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header/user-dropdown-menu.tsx",
            lineNumber: 96,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(DropdownMenuSeparator, {}, void 0, false, {
            fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header/user-dropdown-menu.tsx",
            lineNumber: 99,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            DropdownMenuRadioGroup,
            {
              value: preferences.defaultView,
              onValueChange: (value) => updatePreference("defaultView", value),
              children: [
                /* @__PURE__ */ jsxDEV(DropdownMenuRadioItem, { value: "essentials", children: [
                  /* @__PURE__ */ jsxDEV(Icons.circleCheck, { className: "mr-2" }, void 0, false, {
                    fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header/user-dropdown-menu.tsx",
                    lineNumber: 107,
                    columnNumber: 19
                  }, this),
                  "Essentials"
                ] }, void 0, true, {
                  fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header/user-dropdown-menu.tsx",
                  lineNumber: 106,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV(DropdownMenuRadioItem, { value: "favorites", children: [
                  /* @__PURE__ */ jsxDEV(Icons.starOutline, { className: "mr-2" }, void 0, false, {
                    fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header/user-dropdown-menu.tsx",
                    lineNumber: 111,
                    columnNumber: 19
                  }, this),
                  "Favorites"
                ] }, void 0, true, {
                  fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header/user-dropdown-menu.tsx",
                  lineNumber: 110,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV(DropdownMenuRadioItem, { value: "recents", children: [
                  /* @__PURE__ */ jsxDEV(Icons.history, { className: "mr-2" }, void 0, false, {
                    fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header/user-dropdown-menu.tsx",
                    lineNumber: 115,
                    columnNumber: 19
                  }, this),
                  "Recents"
                ] }, void 0, true, {
                  fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header/user-dropdown-menu.tsx",
                  lineNumber: 114,
                  columnNumber: 17
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header/user-dropdown-menu.tsx",
              lineNumber: 100,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header/user-dropdown-menu.tsx",
          lineNumber: 95,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header/user-dropdown-menu.tsx",
          lineNumber: 94,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header/user-dropdown-menu.tsx",
        lineNumber: 89,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(DropdownMenuSub, { children: [
        /* @__PURE__ */ jsxDEV(DropdownMenuSubTrigger, { children: [
          /* @__PURE__ */ jsxDEV(Icons.roles, { className: "mr-2" }, void 0, false, {
            fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header/user-dropdown-menu.tsx",
            lineNumber: 124,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("span", { children: "Roles" }, void 0, false, {
            fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header/user-dropdown-menu.tsx",
            lineNumber: 125,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header/user-dropdown-menu.tsx",
          lineNumber: 123,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(DropdownMenuPortal, { children: /* @__PURE__ */ jsxDEV(DropdownMenuSubContent, { children: [
          /* @__PURE__ */ jsxDEV(DropdownMenuLabel, { className: "px-3 py-2.5 font-medium", children: "Select Roles" }, void 0, false, {
            fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header/user-dropdown-menu.tsx",
            lineNumber: 129,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(DropdownMenuSeparator, {}, void 0, false, {
            fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header/user-dropdown-menu.tsx",
            lineNumber: 132,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            DropdownMenuCheckboxItem,
            {
              checked: preferences.roles.includes("student"),
              onCheckedChange: (checked) => handleRoleCheckboxChange("student", checked),
              onSelect: (e) => e.preventDefault(),
              children: [
                /* @__PURE__ */ jsxDEV(Icons.graduationCap, { className: "mr-2" }, void 0, false, {
                  fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header/user-dropdown-menu.tsx",
                  lineNumber: 140,
                  columnNumber: 17
                }, this),
                " Student"
              ]
            },
            void 0,
            true,
            {
              fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header/user-dropdown-menu.tsx",
              lineNumber: 133,
              columnNumber: 15
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            DropdownMenuCheckboxItem,
            {
              checked: preferences.roles.includes("employee"),
              onCheckedChange: (checked) => handleRoleCheckboxChange("employee", checked),
              onSelect: (e) => e.preventDefault(),
              children: [
                /* @__PURE__ */ jsxDEV(Icons.briefcaseBusiness, { className: "mr-2" }, void 0, false, {
                  fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header/user-dropdown-menu.tsx",
                  lineNumber: 149,
                  columnNumber: 17
                }, this),
                " Employee"
              ]
            },
            void 0,
            true,
            {
              fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header/user-dropdown-menu.tsx",
              lineNumber: 142,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header/user-dropdown-menu.tsx",
          lineNumber: 128,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header/user-dropdown-menu.tsx",
          lineNumber: 127,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header/user-dropdown-menu.tsx",
        lineNumber: 122,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(DropdownMenuItem, { asChild: true, children: /* @__PURE__ */ jsxDEV("a", { href: "https://www.kpu.ca/it/feedback-onekpu", target: "_blank", children: [
        /* @__PURE__ */ jsxDEV(Icons.feedback, { className: "mr-2" }, void 0, false, {
          fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header/user-dropdown-menu.tsx",
          lineNumber: 156,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("span", { children: "Send Feedback" }, void 0, false, {
          fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header/user-dropdown-menu.tsx",
          lineNumber: 157,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header/user-dropdown-menu.tsx",
        lineNumber: 155,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header/user-dropdown-menu.tsx",
        lineNumber: 154,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(DropdownMenuItem, { onClick: onSignOut, children: [
        /* @__PURE__ */ jsxDEV(Icons.logout, { className: "mr-2" }, void 0, false, {
          fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header/user-dropdown-menu.tsx",
          lineNumber: 161,
          columnNumber: 11
        }, this),
        " Logout"
      ] }, void 0, true, {
        fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header/user-dropdown-menu.tsx",
        lineNumber: 160,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(DropdownMenuSeparator, {}, void 0, false, {
        fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header/user-dropdown-menu.tsx",
        lineNumber: 163,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(DropdownMenuLabel, { className: "flex justify-around", children: [
        /* @__PURE__ */ jsxDEV("a", { href: "https://www.facebook.com/kwantlenU", target: "_blank", children: /* @__PURE__ */ jsxDEV(Icons.facebook, { className: "h-7 w-7 text-[#747474] hover:text-black" }, void 0, false, {
          fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header/user-dropdown-menu.tsx",
          lineNumber: 166,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header/user-dropdown-menu.tsx",
          lineNumber: 165,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("a", { href: "https://x.com/kwantlenu", target: "_blank", children: /* @__PURE__ */ jsxDEV(Icons.x, { className: "h-7 w-7 text-[#747474] hover:text-black" }, void 0, false, {
          fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header/user-dropdown-menu.tsx",
          lineNumber: 169,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header/user-dropdown-menu.tsx",
          lineNumber: 168,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("a", { href: "https://www.instagram.com/kwantlenu", target: "_blank", children: /* @__PURE__ */ jsxDEV(Icons.instagram, { className: "h-7 w-7 text-[#747474] hover:text-black" }, void 0, false, {
          fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header/user-dropdown-menu.tsx",
          lineNumber: 172,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header/user-dropdown-menu.tsx",
          lineNumber: 171,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header/user-dropdown-menu.tsx",
        lineNumber: 164,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header/user-dropdown-menu.tsx",
      lineNumber: 75,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header/user-dropdown-menu.tsx",
    lineNumber: 67,
    columnNumber: 5
  }, this);
}
_s(UserDropdownMenu, "VEEtK9/W+AJQ36MMjHqlL3sBVWc=", false, function() {
  return [usePreferences, useClipboard];
});
_c = UserDropdownMenu;
var _c;
$RefreshReg$(_c, "UserDropdownMenu");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header/user-dropdown-menu.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
