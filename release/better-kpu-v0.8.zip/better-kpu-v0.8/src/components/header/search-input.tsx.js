import { createHotContext as __vite__createHotContext } from "/vendor/vite-client.js";import.meta.hot = __vite__createHotContext("/src/components/header/search-input.tsx.js");import __vite__cjsImport0_react_jsxDevRuntime from "/vendor/.vite-deps-react_jsx-dev-runtime.js__v--752ceaf0.js"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/vendor/react-refresh.js";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header/search-input.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useHotkeys, useOs } from "/vendor/.vite-deps-@mantine_hooks.js__v--752ceaf0.js";
import __vite__cjsImport4_react from "/vendor/.vite-deps-react.js__v--752ceaf0.js"; const useEffect = __vite__cjsImport4_react["useEffect"]; const useRef = __vite__cjsImport4_react["useRef"]; const useState = __vite__cjsImport4_react["useState"];
import { motion, AnimatePresence } from "/vendor/.vite-deps-framer-motion.js__v--752ceaf0.js";
import { Icons } from "/src/components/icons.tsx.js";
import { cn } from "/src/lib/utils.ts.js";
function Kbd({ modKey, children, className, ...props }) {
  return /* @__PURE__ */ jsxDEV(
    "kbd",
    {
      className: cn(
        "inline-flex items-center gap-0.5 space-x-0.5 rounded-lg border border-gray-200 bg-[#F4F4F5] px-1.5 py-0.5 text-center font-sans text-sm font-medium text-gray-600 shadow-md dark:border-[#333336] dark:bg-[#27272A] dark:text-[#D3D3D3] rtl:space-x-reverse",
        className
      ),
      ...props,
      children: [
        modKey === "command" ? /* @__PURE__ */ jsxDEV("abbr", { className: "no-underline", title: "Command", children: "⌘" }, void 0, false, {
          fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header/search-input.tsx",
          lineNumber: 23,
          columnNumber: 7
        }, this) : /* @__PURE__ */ jsxDEV("abbr", { className: "no-underline", title: "Control", children: "⌃" }, void 0, false, {
          fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header/search-input.tsx",
          lineNumber: 27,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV("span", { children }, void 0, false, {
          fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header/search-input.tsx",
          lineNumber: 31,
          columnNumber: 7
        }, this)
      ]
    },
    void 0,
    true,
    {
      fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header/search-input.tsx",
      lineNumber: 15,
      columnNumber: 5
    },
    this
  );
}
_c = Kbd;
export default function SearchInput(props) {
  _s();
  const os = useOs();
  const searchInputRef = useRef(null);
  const [isFocused, setIsFocused] = useState(false);
  useHotkeys([["mod+k", () => searchInputRef.current?.focus()]]);
  useEffect(() => {
    document.addEventListener("keydown", (e) => {
      if (e.key === "Escape")
        searchInputRef.current?.blur();
    });
  }, []);
  return /* @__PURE__ */ jsxDEV("div", { className: "relative", children: [
    /* @__PURE__ */ jsxDEV(Icons.search, { className: "absolute left-6 top-1/2 h-6 w-6 -translate-y-1/2" }, void 0, false, {
      fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header/search-input.tsx",
      lineNumber: 51,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      "input",
      {
        ref: searchInputRef,
        type: "text",
        placeholder: "Search for service...",
        className: "dark:ring-offset-dark-background w-[37.5rem] rounded-full bg-gray-100 px-6 py-3.5 pl-16 font-medium transition-all placeholder:text-[#989898] focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2 dark:bg-[#2E2E2E] dark:placeholder:text-[#747474]",
        onFocus: () => setIsFocused(true),
        onBlur: () => setIsFocused(false),
        ...props
      },
      void 0,
      false,
      {
        fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header/search-input.tsx",
        lineNumber: 52,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(AnimatePresence, { children: !isFocused && /* @__PURE__ */ jsxDEV(
      motion.div,
      {
        initial: { opacity: 0 },
        animate: { opacity: 1 },
        exit: { opacity: 0 },
        transition: { duration: 0.2 },
        children: /* @__PURE__ */ jsxDEV(
          Kbd,
          {
            "data-hide-on-focus": isFocused,
            modKey: os === "macos" ? "command" : "ctrl",
            className: "absolute right-4 top-1/2 -translate-y-1/2",
            children: "K"
          },
          void 0,
          false,
          {
            fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header/search-input.tsx",
            lineNumber: 71,
            columnNumber: 13
          },
          this
        )
      },
      "kbd-focus",
      false,
      {
        fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header/search-input.tsx",
        lineNumber: 64,
        columnNumber: 9
      },
      this
    ) }, void 0, false, {
      fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header/search-input.tsx",
      lineNumber: 62,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header/search-input.tsx",
    lineNumber: 50,
    columnNumber: 5
  }, this);
}
_s(SearchInput, "IYw/hJpTQcB58SGyrR0Bl08NTAo=", false, function() {
  return [useOs, useHotkeys];
});
_c2 = SearchInput;
var _c, _c2;
$RefreshReg$(_c, "Kbd");
$RefreshReg$(_c2, "SearchInput");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header/search-input.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
