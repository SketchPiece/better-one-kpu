import { createHotContext as __vite__createHotContext } from "/vendor/vite-client.js";import.meta.hot = __vite__createHotContext("/src/components/one-kpu-logo.tsx.js");import __vite__cjsImport0_react_jsxDevRuntime from "/vendor/.vite-deps-react_jsx-dev-runtime.js__v--752ceaf0.js"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/vendor/react-refresh.js";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/one-kpu-logo.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
export default function OneKpuLogo(props) {
  return /* @__PURE__ */ jsxDEV(
    "svg",
    {
      xmlns: "http://www.w3.org/2000/svg",
      width: "148",
      height: "39",
      fill: "none",
      viewBox: "0 0 148 39",
      className: "icon",
      ...props,
      children: [
        /* @__PURE__ */ jsxDEV("g", { clipPath: "url(#clip0_277_251)", children: [
          /* @__PURE__ */ jsxDEV("g", { clipPath: "url(#clip1_277_251)", children: [
            /* @__PURE__ */ jsxDEV(
              "path",
              {
                fill: "#8C2332",
                d: "M25.326 19.021H6.522v-2.017h8.137l-8.137-6.356V3.5l9.402 7.929L25.326 3.5v7.148l-8.137 6.356h8.137v2.017z"
              },
              void 0,
              false,
              {
                fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/one-kpu-logo.tsx",
                lineNumber: 16,
                columnNumber: 11
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "path",
              {
                className: "text-[#414042] dark:text-[#D3D3D3]",
                fill: "currentColor",
                d: "M5.509 27.853l5.025-5.667H7.828l-5.635 6.493v-6.493H0v13.156h2.193v-3.816l1.816-2.037 4.058 5.834.013.019h2.66L5.51 27.853zM20.525 24.859c-.208-.528-.518-1-.909-1.386a3.99 3.99 0 00-1.44-.887 5.471 5.471 0 00-1.888-.307h-4.724v13.04h2.174v-4.165h2.314a5.933 5.933 0 001.86-.285 4.477 4.477 0 001.523-.853 3.951 3.951 0 001.03-1.39c.261-.606.39-1.27.379-1.938v-.037a4.84 4.84 0 00-.319-1.792zm-6.787-.395h2.381c.654-.036 1.301.165 1.84.572.228.202.409.46.527.754.118.294.169.615.15.935v.04c.006.309-.05.616-.167.897a2.06 2.06 0 01-.505.732 2.603 2.603 0 01-1.845.633h-2.38v-4.563zM29.823 22.238v7.512c0 1.18-.264 2.078-.785 2.669a2.843 2.843 0 01-.993.695c-.372.154-.77.222-1.167.2a2.606 2.606 0 01-1.18-.209 2.81 2.81 0 01-.994-.722c-.522-.617-.787-1.533-.787-2.724v-7.421h-2.178v7.512a7.906 7.906 0 00.36 2.49c.219.676.57 1.292 1.03 1.804a4.243 4.243 0 001.612 1.096c.678.25 1.389.37 2.104.36.723.01 1.443-.11 2.13-.36a4.2 4.2 0 001.62-1.107 5.186 5.186 0 001.04-1.842c.256-.82.38-1.685.365-2.552v-7.402h-2.177z"
              },
              void 0,
              false,
              {
                fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/one-kpu-logo.tsx",
                lineNumber: 20,
                columnNumber: 11
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/one-kpu-logo.tsx",
            lineNumber: 15,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV(
            "path",
            {
              fill: "currentColor",
              d: "M53.048 29.26c-2.652 0-4.637-.693-5.954-2.08-1.317-1.404-1.976-3.57-1.976-6.5 0-3.05.659-5.26 1.976-6.63s3.302-2.054 5.954-2.054c2.67 0 4.654.685 5.954 2.054 1.317 1.37 1.976 3.58 1.976 6.63 0 2.93-.659 5.096-1.976 6.5-1.3 1.387-3.285 2.08-5.954 2.08zm0-2.392c1.75 0 3.033-.477 3.848-1.43.832-.97 1.248-2.557 1.248-4.758 0-2.323-.416-3.943-1.248-4.862-.815-.936-2.097-1.404-3.848-1.404-1.733 0-3.016.468-3.848 1.404-.815.919-1.222 2.54-1.222 4.862 0 2.201.407 3.787 1.222 4.758.832.953 2.115 1.43 3.848 1.43zM63.742 29V12.256h2.495l8.737 12.324V12.256h2.807V29h-2.496l-8.71-12.298V29h-2.834zm17.341 0V12.256h11.674v2.21h-8.84v5.07h7.878v2.184h-7.878v5.096h8.84V29H81.083zm13.775 0v-2.21h2.392V29h-2.392zm5.167 0V12.256h2.834v7.696l7.124-7.696h3.276l-6.162 6.76L113.519 29h-3.016l-5.174-8.19-2.47 2.652V29h-2.834zm16.25 0V12.256h7.462c1.282 0 2.34.243 3.172.728a4.48 4.48 0 011.846 2.002c.398.832.598 1.785.598 2.86 0 1.664-.52 2.999-1.56 4.004-1.023 1.005-2.41 1.508-4.16 1.508h-4.524V29h-2.834zm2.834-7.878h4.004c1.126 0 1.976-.295 2.548-.884.572-.59.858-1.387.858-2.392 0-1.075-.278-1.907-.832-2.496-.538-.59-1.352-.884-2.444-.884h-4.134v6.656zm19.652 8.138c-2.306 0-4.1-.555-5.382-1.664-1.266-1.11-1.898-2.713-1.898-4.81v-10.53h2.834v10.426c0 1.404.381 2.453 1.144 3.146.78.693 1.88 1.04 3.302 1.04 1.404 0 2.487-.347 3.25-1.04.78-.693 1.17-1.742 1.17-3.146V12.256h2.808v10.53c0 2.097-.633 3.7-1.898 4.81-1.266 1.11-3.042 1.664-5.33 1.664z"
            },
            void 0,
            false,
            {
              fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/one-kpu-logo.tsx",
              lineNumber: 26,
              columnNumber: 9
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/one-kpu-logo.tsx",
          lineNumber: 14,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV("defs", { children: [
          /* @__PURE__ */ jsxDEV("clipPath", { id: "clip0_277_251", children: /* @__PURE__ */ jsxDEV("path", { fill: "currentColor", d: "M0 0H148V39H0z" }, void 0, false, {
            fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/one-kpu-logo.tsx",
            lineNumber: 33,
            columnNumber: 11
          }, this) }, void 0, false, {
            fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/one-kpu-logo.tsx",
            lineNumber: 32,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV("clipPath", { id: "clip1_277_251", children: /* @__PURE__ */ jsxDEV(
            "path",
            {
              fill: "currentColor",
              d: "M0 0H32V32H0z",
              transform: "translate(0 3.5)"
            },
            void 0,
            false,
            {
              fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/one-kpu-logo.tsx",
              lineNumber: 36,
              columnNumber: 11
            },
            this
          ) }, void 0, false, {
            fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/one-kpu-logo.tsx",
            lineNumber: 35,
            columnNumber: 9
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/one-kpu-logo.tsx",
          lineNumber: 31,
          columnNumber: 7
        }, this)
      ]
    },
    void 0,
    true,
    {
      fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/one-kpu-logo.tsx",
      lineNumber: 5,
      columnNumber: 5
    },
    this
  );
}
_c = OneKpuLogo;
var _c;
$RefreshReg$(_c, "OneKpuLogo");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/one-kpu-logo.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
