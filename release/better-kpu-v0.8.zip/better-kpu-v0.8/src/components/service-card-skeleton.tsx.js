import { createHotContext as __vite__createHotContext } from "/vendor/vite-client.js";import.meta.hot = __vite__createHotContext("/src/components/service-card-skeleton.tsx.js");import __vite__cjsImport0_react_jsxDevRuntime from "/vendor/.vite-deps-react_jsx-dev-runtime.js__v--fbc305df.js"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/vendor/react-refresh.js";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/service-card-skeleton.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { Skeleton } from "/src/components/ui/skeleton.tsx.js";
export default function ServiceCardSkeleton({
  amount = 1
}) {
  return /* @__PURE__ */ jsxDEV(Fragment, { children: Array.from({ length: amount }).map(
    (_, index) => /* @__PURE__ */ jsxDEV(
      "div",
      {
        className: "flex items-center justify-center gap-4 rounded-xl px-8 py-6",
        children: [
          /* @__PURE__ */ jsxDEV(Skeleton, { className: "h-20 w-20 rounded-full border border-[#F0F0F0]" }, void 0, false, {
            fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/service-card-skeleton.tsx",
            lineNumber: 16,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex flex-1 flex-col", children: [
            /* @__PURE__ */ jsxDEV(Skeleton, { className: "h-7 w-full max-w-36" }, void 0, false, {
              fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/service-card-skeleton.tsx",
              lineNumber: 18,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV(Skeleton, { className: "mt-1 h-4 w-full" }, void 0, false, {
              fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/service-card-skeleton.tsx",
              lineNumber: 19,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV(Skeleton, { className: "mt-1 h-4 w-full" }, void 0, false, {
              fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/service-card-skeleton.tsx",
              lineNumber: 20,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV(Skeleton, { className: "mt-1 h-4 w-full" }, void 0, false, {
              fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/service-card-skeleton.tsx",
              lineNumber: 21,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV(Skeleton, { className: "mt-1 h-4 w-full" }, void 0, false, {
              fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/service-card-skeleton.tsx",
              lineNumber: 22,
              columnNumber: 13
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/service-card-skeleton.tsx",
            lineNumber: 17,
            columnNumber: 11
          }, this)
        ]
      },
      index,
      true,
      {
        fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/service-card-skeleton.tsx",
        lineNumber: 12,
        columnNumber: 7
      },
      this
    )
  ) }, void 0, false, {
    fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/service-card-skeleton.tsx",
    lineNumber: 10,
    columnNumber: 5
  }, this);
}
_c = ServiceCardSkeleton;
var _c;
$RefreshReg$(_c, "ServiceCardSkeleton");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/service-card-skeleton.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
