import { createHotContext as __vite__createHotContext } from "/vendor/vite-client.js";import.meta.hot = __vite__createHotContext("/src/components/header.tsx.js");import __vite__cjsImport0_react_jsxDevRuntime from "/vendor/.vite-deps-react_jsx-dev-runtime.js__v--12d27e15.js"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/vendor/react-refresh.js";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/vendor/.vite-deps-react.js__v--12d27e15.js"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useRef = __vite__cjsImport3_react["useRef"];
import oneKpuLogo from "/src/assets/one-kpu-logo.svg__import.js";
import { Icons } from "/src/components/icons.tsx.js";
import { Avatar, AvatarFallback } from "/src/components/ui/avatar.tsx.js";
import { Button } from "/src/components/ui/button.tsx.js";
import { useHotkeys } from "/vendor/.vite-deps-@mantine_hooks.js__v--6119fd75.js";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuPortal,
  DropdownMenuSeparator,
  DropdownMenuSub,
  DropdownMenuSubContent,
  DropdownMenuSubTrigger,
  DropdownMenuTrigger
} from "/src/components/ui/dropdown-menu.tsx.js";
function SearchInput(props) {
  _s();
  const searchInputRef = useRef(null);
  useHotkeys([["mod+k", () => searchInputRef.current?.focus()]]);
  useEffect(() => {
    document.addEventListener("keydown", (e) => {
      if (e.key === "Escape")
        searchInputRef.current?.blur();
    });
  }, []);
  return /* @__PURE__ */ jsxDEV("div", { className: "relative", children: [
    /* @__PURE__ */ jsxDEV(Icons.search, { className: "absolute left-6 top-1/2 h-6 w-6 -translate-y-1/2" }, void 0, false, {
      fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header.tsx",
      lineNumber: 35,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      "input",
      {
        ref: searchInputRef,
        type: "text",
        placeholder: "Search for services...",
        className: "w-[37.5rem] rounded-full bg-gray-100 px-6 py-3.5 pl-16 font-medium transition-all placeholder:text-[#989898] focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2",
        ...props
      },
      void 0,
      false,
      {
        fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header.tsx",
        lineNumber: 36,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header.tsx",
    lineNumber: 34,
    columnNumber: 5
  }, this);
}
_s(SearchInput, "WusQnD98X9VwdFrfhMiDcY1yETA=", false, function() {
  return [useHotkeys];
});
_c = SearchInput;
function UserDropdownMenu() {
  return /* @__PURE__ */ jsxDEV(DropdownMenu, { children: [
    /* @__PURE__ */ jsxDEV(DropdownMenuTrigger, { asChild: true, children: /* @__PURE__ */ jsxDEV("button", { className: "rounded-full transition-all focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2", children: /* @__PURE__ */ jsxDEV(Avatar, { children: /* @__PURE__ */ jsxDEV(AvatarFallback, { children: "AL" }, void 0, false, {
      fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header.tsx",
      lineNumber: 53,
      columnNumber: 13
    }, this) }, void 0, false, {
      fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header.tsx",
      lineNumber: 52,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header.tsx",
      lineNumber: 51,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header.tsx",
      lineNumber: 50,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(DropdownMenuContent, { align: "end", children: [
      /* @__PURE__ */ jsxDEV(DropdownMenuLabel, { className: "flex flex-col", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "font-medium", children: "Andrew" }, void 0, false, {
          fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header.tsx",
          lineNumber: 59,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "text-sm", children: "lubkin.andrey@gmail.com" }, void 0, false, {
          fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header.tsx",
          lineNumber: 60,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header.tsx",
        lineNumber: 58,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(DropdownMenuSeparator, {}, void 0, false, {
        fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header.tsx",
        lineNumber: 62,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(DropdownMenuSub, { children: [
        /* @__PURE__ */ jsxDEV(DropdownMenuSubTrigger, { children: [
          /* @__PURE__ */ jsxDEV(Icons.roles, { className: "mr-2" }, void 0, false, {
            fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header.tsx",
            lineNumber: 65,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("span", { children: "Roles" }, void 0, false, {
            fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header.tsx",
            lineNumber: 66,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header.tsx",
          lineNumber: 64,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(DropdownMenuPortal, { children: /* @__PURE__ */ jsxDEV(DropdownMenuSubContent, { children: [
          /* @__PURE__ */ jsxDEV(DropdownMenuItem, { children: "Admin" }, void 0, false, {
            fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header.tsx",
            lineNumber: 70,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(DropdownMenuItem, { children: "User" }, void 0, false, {
            fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header.tsx",
            lineNumber: 71,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header.tsx",
          lineNumber: 69,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header.tsx",
          lineNumber: 68,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header.tsx",
        lineNumber: 63,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(DropdownMenuItem, { children: [
        /* @__PURE__ */ jsxDEV(Icons.feedback, { className: "mr-2" }, void 0, false, {
          fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header.tsx",
          lineNumber: 76,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("span", { children: "Send Feedback" }, void 0, false, {
          fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header.tsx",
          lineNumber: 77,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header.tsx",
        lineNumber: 75,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(DropdownMenuItem, { children: [
        /* @__PURE__ */ jsxDEV(Icons.logout, { className: "mr-2" }, void 0, false, {
          fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header.tsx",
          lineNumber: 80,
          columnNumber: 11
        }, this),
        " Logout"
      ] }, void 0, true, {
        fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header.tsx",
        lineNumber: 79,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(DropdownMenuSeparator, {}, void 0, false, {
        fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header.tsx",
        lineNumber: 82,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(DropdownMenuLabel, { className: "flex justify-around", children: [
        /* @__PURE__ */ jsxDEV("a", { href: "#", children: /* @__PURE__ */ jsxDEV(Icons.facebook, { className: "h-7 w-7 text-[#747474] hover:text-black" }, void 0, false, {
          fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header.tsx",
          lineNumber: 85,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header.tsx",
          lineNumber: 84,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("a", { href: "#", children: /* @__PURE__ */ jsxDEV(Icons.x, { className: "h-7 w-7 text-[#747474] hover:text-black" }, void 0, false, {
          fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header.tsx",
          lineNumber: 88,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header.tsx",
          lineNumber: 87,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("a", { href: "#", children: /* @__PURE__ */ jsxDEV(Icons.instagram, { className: "h-7 w-7 text-[#747474] hover:text-black" }, void 0, false, {
          fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header.tsx",
          lineNumber: 91,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header.tsx",
          lineNumber: 90,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header.tsx",
        lineNumber: 83,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header.tsx",
      lineNumber: 57,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header.tsx",
    lineNumber: 49,
    columnNumber: 5
  }, this);
}
_c2 = UserDropdownMenu;
export default function Header() {
  return /* @__PURE__ */ jsxDEV("header", { className: "flex items-center justify-between px-6 py-4", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: /* @__PURE__ */ jsxDEV(
      "a",
      {
        href: "#",
        className: "block w-fit rounded-full p-2 transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary",
        children: /* @__PURE__ */ jsxDEV("img", { src: chrome.runtime.getURL(oneKpuLogo), alt: "One KPU Logo" }, void 0, false, {
          fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header.tsx",
          lineNumber: 107,
          columnNumber: 11
        }, this)
      },
      void 0,
      false,
      {
        fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header.tsx",
        lineNumber: 103,
        columnNumber: 9
      },
      this
    ) }, void 0, false, {
      fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header.tsx",
      lineNumber: 102,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(SearchInput, {}, void 0, false, {
      fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header.tsx",
      lineNumber: 110,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex flex-1 items-center justify-end gap-4", children: [
      /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", size: "icon", children: /* @__PURE__ */ jsxDEV(Icons.bellDot, { className: "h-6 w-6" }, void 0, false, {
        fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header.tsx",
        lineNumber: 114,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header.tsx",
        lineNumber: 113,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(UserDropdownMenu, {}, void 0, false, {
        fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header.tsx",
        lineNumber: 116,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header.tsx",
      lineNumber: 112,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header.tsx",
    lineNumber: 101,
    columnNumber: 5
  }, this);
}
_c3 = Header;
var _c, _c2, _c3;
$RefreshReg$(_c, "SearchInput");
$RefreshReg$(_c2, "UserDropdownMenu");
$RefreshReg$(_c3, "Header");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/header.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
