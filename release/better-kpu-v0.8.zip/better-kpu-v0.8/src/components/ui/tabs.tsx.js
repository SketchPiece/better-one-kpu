import { createHotContext as __vite__createHotContext } from "/vendor/vite-client.js";import.meta.hot = __vite__createHotContext("/src/components/ui/tabs.tsx.js");import __vite__cjsImport0_react_jsxDevRuntime from "/vendor/.vite-deps-react_jsx-dev-runtime.js__v--64670dce.js"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/vendor/react-refresh.js";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/ui/tabs.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import __vite__cjsImport3_react from "/vendor/.vite-deps-react.js__v--64670dce.js"; const React = ((m) => m?.__esModule ? m : { ...(typeof m === 'object' && !Array.isArray(m) || typeof m === 'function' ? m : {}), default: m })(__vite__cjsImport3_react);
import * as TabsPrimitive from "/vendor/.vite-deps-@radix-ui_react-tabs.js__v--64670dce.js";
import { cn } from "/src/lib/utils.ts.js";
const Tabs = TabsPrimitive.Root;
const TabsList = React.forwardRef(
  _c = ({ className, ...props }, ref) => /* @__PURE__ */ jsxDEV(
    TabsPrimitive.List,
    {
      ref,
      className: cn("inline-flex items-center justify-center gap-2", className),
      ...props
    },
    void 0,
    false,
    {
      fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/ui/tabs.tsx",
      lineNumber: 12,
      columnNumber: 1
    },
    this
  )
);
_c2 = TabsList;
TabsList.displayName = TabsPrimitive.List.displayName;
const TabsTrigger = React.forwardRef(
  _c3 = ({ className, ...props }, ref) => /* @__PURE__ */ jsxDEV(
    TabsPrimitive.Trigger,
    {
      ref,
      className: cn(
        "inline-flex items-center justify-center whitespace-nowrap rounded-full border border-[#EFEFEF] px-4 py-2.5 font-medium ring-offset-white transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 data-[state=active]:border-primary data-[state=active]:bg-primary data-[state=active]:text-white",
        className
      ),
      ...props
    },
    void 0,
    false,
    {
      fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/ui/tabs.tsx",
      lineNumber: 24,
      columnNumber: 1
    },
    this
  )
);
_c4 = TabsTrigger;
TabsTrigger.displayName = TabsPrimitive.Trigger.displayName;
const TabsContent = React.forwardRef(
  _c5 = ({ className, ...props }, ref) => /* @__PURE__ */ jsxDEV(
    TabsPrimitive.Content,
    {
      ref,
      className: cn(
        "mt-2 ring-offset-white focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-slate-950 focus-visible:ring-offset-2 dark:ring-offset-slate-950 dark:focus-visible:ring-slate-300",
        className
      ),
      ...props
    },
    void 0,
    false,
    {
      fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/ui/tabs.tsx",
      lineNumber: 39,
      columnNumber: 1
    },
    this
  )
);
_c6 = TabsContent;
TabsContent.displayName = TabsPrimitive.Content.displayName;
export { Tabs, TabsList, TabsTrigger, TabsContent };
var _c, _c2, _c3, _c4, _c5, _c6;
$RefreshReg$(_c, "TabsList$React.forwardRef");
$RefreshReg$(_c2, "TabsList");
$RefreshReg$(_c3, "TabsTrigger$React.forwardRef");
$RefreshReg$(_c4, "TabsTrigger");
$RefreshReg$(_c5, "TabsContent$React.forwardRef");
$RefreshReg$(_c6, "TabsContent");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/ui/tabs.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
