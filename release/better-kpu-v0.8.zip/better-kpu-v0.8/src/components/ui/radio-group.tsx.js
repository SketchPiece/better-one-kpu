import { createHotContext as __vite__createHotContext } from "/vendor/vite-client.js";import.meta.hot = __vite__createHotContext("/src/components/ui/radio-group.tsx.js");import __vite__cjsImport0_react_jsxDevRuntime from "/vendor/.vite-deps-react_jsx-dev-runtime.js__v--64670dce.js"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/vendor/react-refresh.js";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/ui/radio-group.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import __vite__cjsImport3_react from "/vendor/.vite-deps-react.js__v--64670dce.js"; const React = ((m) => m?.__esModule ? m : { ...(typeof m === 'object' && !Array.isArray(m) || typeof m === 'function' ? m : {}), default: m })(__vite__cjsImport3_react);
import * as RadioGroupPrimitive from "/vendor/.vite-deps-@radix-ui_react-radio-group.js__v--64670dce.js";
import { Circle } from "/vendor/.vite-deps-lucide-react.js__v--64670dce.js";
import { cn } from "/src/lib/utils.ts.js";
const RadioGroup = React.forwardRef(_c = ({ className, ...props }, ref) => {
  return /* @__PURE__ */ jsxDEV(
    RadioGroupPrimitive.Root,
    {
      className: cn("grid gap-2", className),
      ...props,
      ref
    },
    void 0,
    false,
    {
      fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/ui/radio-group.tsx",
      lineNumber: 12,
      columnNumber: 5
    },
    this
  );
});
_c2 = RadioGroup;
RadioGroup.displayName = RadioGroupPrimitive.Root.displayName;
const RadioGroupItem = React.forwardRef(_c3 = ({ className, ...props }, ref) => {
  return /* @__PURE__ */ jsxDEV(
    RadioGroupPrimitive.Item,
    {
      ref,
      className: cn(
        "aspect-square h-4 w-4 rounded-full border border-slate-200 border-slate-900 text-slate-900 ring-offset-white focus:outline-none focus-visible:ring-2 focus-visible:ring-slate-950 focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 dark:border-slate-800 dark:border-slate-50 dark:text-slate-50 dark:ring-offset-slate-950 dark:focus-visible:ring-slate-300",
        className
      ),
      ...props,
      children: /* @__PURE__ */ jsxDEV(RadioGroupPrimitive.Indicator, { className: "flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(Circle, { className: "h-2.5 w-2.5 fill-current text-current" }, void 0, false, {
        fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/ui/radio-group.tsx",
        lineNumber: 35,
        columnNumber: 9
      }, this) }, void 0, false, {
        fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/ui/radio-group.tsx",
        lineNumber: 34,
        columnNumber: 7
      }, this)
    },
    void 0,
    false,
    {
      fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/ui/radio-group.tsx",
      lineNumber: 26,
      columnNumber: 5
    },
    this
  );
});
_c4 = RadioGroupItem;
RadioGroupItem.displayName = RadioGroupPrimitive.Item.displayName;
export { RadioGroup, RadioGroupItem };
var _c, _c2, _c3, _c4;
$RefreshReg$(_c, "RadioGroup$React.forwardRef");
$RefreshReg$(_c2, "RadioGroup");
$RefreshReg$(_c3, "RadioGroupItem$React.forwardRef");
$RefreshReg$(_c4, "RadioGroupItem");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/ui/radio-group.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
