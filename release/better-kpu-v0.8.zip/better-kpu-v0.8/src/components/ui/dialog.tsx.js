import { createHotContext as __vite__createHotContext } from "/vendor/vite-client.js";import.meta.hot = __vite__createHotContext("/src/components/ui/dialog.tsx.js");import __vite__cjsImport0_react_jsxDevRuntime from "/vendor/.vite-deps-react_jsx-dev-runtime.js__v--752ceaf0.js"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/vendor/react-refresh.js";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/ui/dialog.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import __vite__cjsImport3_react from "/vendor/.vite-deps-react.js__v--752ceaf0.js"; const React = ((m) => m?.__esModule ? m : { ...(typeof m === 'object' && !Array.isArray(m) || typeof m === 'function' ? m : {}), default: m })(__vite__cjsImport3_react);
import * as DialogPrimitive from "/vendor/.vite-deps-@radix-ui_react-dialog.js__v--752ceaf0.js";
import { X } from "/vendor/.vite-deps-lucide-react.js__v--752ceaf0.js";
import { cn } from "/src/lib/utils.ts.js";
const Dialog = DialogPrimitive.Root;
const DialogTrigger = DialogPrimitive.Trigger;
const DialogPortal = DialogPrimitive.Portal;
const DialogClose = DialogPrimitive.Close;
const DialogOverlay = React.forwardRef(
  _c = ({ className, ...props }, ref) => /* @__PURE__ */ jsxDEV(
    DialogPrimitive.Overlay,
    {
      ref,
      className: cn(
        "fixed inset-0 z-50 bg-black/80 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0",
        className
      ),
      ...props
    },
    void 0,
    false,
    {
      fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/ui/dialog.tsx",
      lineNumber: 19,
      columnNumber: 1
    },
    this
  )
);
_c2 = DialogOverlay;
DialogOverlay.displayName = DialogPrimitive.Overlay.displayName;
const DialogContent = React.forwardRef(
  _c3 = ({ className, children, ...props }, ref) => /* @__PURE__ */ jsxDEV(DialogPortal, { children: [
    /* @__PURE__ */ jsxDEV(DialogOverlay, {}, void 0, false, {
      fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/ui/dialog.tsx",
      lineNumber: 35,
      columnNumber: 5
    }, this),
    /* @__PURE__ */ jsxDEV(
      DialogPrimitive.Content,
      {
        ref,
        className: cn(
          "fixed left-[50%] top-[50%] z-50 grid w-full max-w-lg translate-x-[-50%] translate-y-[-50%] gap-4 border bg-white p-6 shadow-lg duration-200 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[state=closed]:slide-out-to-left-1/2 data-[state=closed]:slide-out-to-top-[48%] data-[state=open]:slide-in-from-left-1/2 data-[state=open]:slide-in-from-top-[48%] dark:border-slate-800 dark:bg-slate-950 sm:rounded-2xl",
          className
        ),
        ...props,
        children: [
          children,
          /* @__PURE__ */ jsxDEV(DialogPrimitive.Close, { className: "dark:ring-offset-dark-background absolute right-4 top-4 rounded-sm opacity-70 ring-offset-white transition-all hover:opacity-100 focus:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2 disabled:pointer-events-none data-[state=open]:bg-slate-100 data-[state=open]:text-slate-500", children: [
            /* @__PURE__ */ jsxDEV(X, {}, void 0, false, {
              fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/ui/dialog.tsx",
              lineNumber: 46,
              columnNumber: 9
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "sr-only", children: "Close" }, void 0, false, {
              fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/ui/dialog.tsx",
              lineNumber: 47,
              columnNumber: 9
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/ui/dialog.tsx",
            lineNumber: 45,
            columnNumber: 7
          }, this)
        ]
      },
      void 0,
      true,
      {
        fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/ui/dialog.tsx",
        lineNumber: 36,
        columnNumber: 5
      },
      this
    )
  ] }, void 0, true, {
    fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/ui/dialog.tsx",
    lineNumber: 34,
    columnNumber: 1
  }, this)
);
_c4 = DialogContent;
DialogContent.displayName = DialogPrimitive.Content.displayName;
const DialogHeader = ({
  className,
  ...props
}) => /* @__PURE__ */ jsxDEV(
  "div",
  {
    className: cn(
      "flex flex-col space-y-1.5 text-center sm:text-left",
      className
    ),
    ...props
  },
  void 0,
  false,
  {
    fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/ui/dialog.tsx",
    lineNumber: 58,
    columnNumber: 1
  },
  this
);
_c5 = DialogHeader;
DialogHeader.displayName = "DialogHeader";
const DialogFooter = ({
  className,
  ...props
}) => /* @__PURE__ */ jsxDEV(
  "div",
  {
    className: cn(
      "flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2",
      className
    ),
    ...props
  },
  void 0,
  false,
  {
    fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/ui/dialog.tsx",
    lineNumber: 72,
    columnNumber: 1
  },
  this
);
_c6 = DialogFooter;
DialogFooter.displayName = "DialogFooter";
const DialogTitle = React.forwardRef(
  _c7 = ({ className, ...props }, ref) => /* @__PURE__ */ jsxDEV(
    DialogPrimitive.Title,
    {
      ref,
      className: cn(
        "text-lg font-semibold leading-none tracking-tight",
        className
      ),
      ...props
    },
    void 0,
    false,
    {
      fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/ui/dialog.tsx",
      lineNumber: 86,
      columnNumber: 1
    },
    this
  )
);
_c8 = DialogTitle;
DialogTitle.displayName = DialogPrimitive.Title.displayName;
const DialogDescription = React.forwardRef(
  _c9 = ({ className, ...props }, ref) => /* @__PURE__ */ jsxDEV(
    DialogPrimitive.Description,
    {
      ref,
      className: cn("text-sm text-black/80", className),
      ...props
    },
    void 0,
    false,
    {
      fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/ui/dialog.tsx",
      lineNumber: 101,
      columnNumber: 1
    },
    this
  )
);
_c10 = DialogDescription;
DialogDescription.displayName = DialogPrimitive.Description.displayName;
export {
  Dialog,
  DialogPortal,
  DialogOverlay,
  DialogClose,
  DialogTrigger,
  DialogContent,
  DialogHeader,
  DialogFooter,
  DialogTitle,
  DialogDescription
};
var _c, _c2, _c3, _c4, _c5, _c6, _c7, _c8, _c9, _c10;
$RefreshReg$(_c, "DialogOverlay$React.forwardRef");
$RefreshReg$(_c2, "DialogOverlay");
$RefreshReg$(_c3, "DialogContent$React.forwardRef");
$RefreshReg$(_c4, "DialogContent");
$RefreshReg$(_c5, "DialogHeader");
$RefreshReg$(_c6, "DialogFooter");
$RefreshReg$(_c7, "DialogTitle$React.forwardRef");
$RefreshReg$(_c8, "DialogTitle");
$RefreshReg$(_c9, "DialogDescription$React.forwardRef");
$RefreshReg$(_c10, "DialogDescription");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/ui/dialog.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
