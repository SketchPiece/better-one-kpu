import { createHotContext as __vite__createHotContext } from "/vendor/vite-client.js";import.meta.hot = __vite__createHotContext("/src/components/notification-popover/notification-content-renderer.tsx.js");import __vite__cjsImport0_react_jsxDevRuntime from "/vendor/.vite-deps-react_jsx-dev-runtime.js__v--752ceaf0.js"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/vendor/react-refresh.js";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/notification-popover/notification-content-renderer.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import __vite__cjsImport3_react_jsxRuntime from "/vendor/.vite-deps-react_jsx-runtime.js__v--752ceaf0.js"; const Fragment = __vite__cjsImport3_react_jsxRuntime["Fragment"];
const renderNode = (node) => {
  const type = node.type.toLowerCase();
  if (type === "text") {
    return node?.value;
  }
  if (type === "br") {
    return /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
      fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/notification-popover/notification-content-renderer.tsx",
      lineNumber: 16,
      columnNumber: 12
    }, this);
  }
  if (type === "p") {
    return /* @__PURE__ */ jsxDEV("p", { className: "my-2 text-sm", children: node.children && node.children?.map((child) => renderNode(child)) }, void 0, false, {
      fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/notification-popover/notification-content-renderer.tsx",
      lineNumber: 21,
      columnNumber: 7
    }, this);
  }
  const Tag = type;
  return /* @__PURE__ */ jsxDEV(Tag, { children: node.children && node.children.map(
    (child, index) => /* @__PURE__ */ jsxDEV(Fragment, { children: renderNode(child) }, index, false, {
      fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/notification-popover/notification-content-renderer.tsx",
      lineNumber: 33,
      columnNumber: 7
    }, this)
  ) }, void 0, false, {
    fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/notification-popover/notification-content-renderer.tsx",
    lineNumber: 30,
    columnNumber: 5
  }, this);
};
export default function NotificationContentRenderer({
  content,
  showMore = false
}) {
  if (showMore) {
    return /* @__PURE__ */ jsxDEV("div", { children: content.map(
      (node2, index) => /* @__PURE__ */ jsxDEV(Fragment, { children: renderNode(node2) }, index, false, {
        fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/notification-popover/notification-content-renderer.tsx",
        lineNumber: 47,
        columnNumber: 9
      }, this)
    ) }, void 0, false, {
      fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/notification-popover/notification-content-renderer.tsx",
      lineNumber: 45,
      columnNumber: 7
    }, this);
  }
  const node = content[0];
  return renderNode(node);
}
_c = NotificationContentRenderer;
var _c;
$RefreshReg$(_c, "NotificationContentRenderer");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/notification-popover/notification-content-renderer.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
