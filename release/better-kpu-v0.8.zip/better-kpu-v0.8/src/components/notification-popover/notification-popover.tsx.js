import { createHotContext as __vite__createHotContext } from "/vendor/vite-client.js";import.meta.hot = __vite__createHotContext("/src/components/notification-popover/notification-popover.tsx.js");import __vite__cjsImport0_react_jsxDevRuntime from "/vendor/.vite-deps-react_jsx-dev-runtime.js__v--752ceaf0.js"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/vendor/react-refresh.js";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/notification-popover/notification-popover.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { Icons } from "/src/components/icons.tsx.js";
import { Button } from "/src/components/ui/button.tsx.js";
import { Popover, PopoverContent, PopoverTrigger } from "/src/components/ui/popover.tsx.js";
import NotificationContentRenderer from "/src/components/notification-popover/notification-content-renderer.tsx.js";
import __vite__cjsImport7_react from "/vendor/.vite-deps-react.js__v--752ceaf0.js"; const useState = __vite__cjsImport7_react["useState"];
function NotificationCard({ title, content }) {
  _s();
  const [isShowMore, setIsShowMore] = useState(false);
  return /* @__PURE__ */ jsxDEV("div", { className: "m-2 w-fit gap-4 rounded-xl p-2 hover:bg-[#F9F9F9]", children: [
    /* @__PURE__ */ jsxDEV("h5", { className: "text-nowrap font-medium leading-none", children: title }, void 0, false, {
      fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/notification-popover/notification-popover.tsx",
      lineNumber: 17,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "mt-2", children: /* @__PURE__ */ jsxDEV(NotificationContentRenderer, { content, showMore: isShowMore }, void 0, false, {
      fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/notification-popover/notification-popover.tsx",
      lineNumber: 19,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/notification-popover/notification-popover.tsx",
      lineNumber: 18,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      "button",
      {
        className: "dark:ring-offset-dark-background text-sm text-primary hover:text-primary/80 focus:outline-none",
        onClick: () => setIsShowMore(!isShowMore),
        children: isShowMore ? "Show less" : "Show more"
      },
      void 0,
      false,
      {
        fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/notification-popover/notification-popover.tsx",
        lineNumber: 21,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/notification-popover/notification-popover.tsx",
    lineNumber: 16,
    columnNumber: 5
  }, this);
}
_s(NotificationCard, "KoNWCmFO4VEY08lHySxD90gKqPw=");
_c = NotificationCard;
export default function NotificationsPopover({
  notifications
}) {
  const showDot = (notifications?.length ?? 0) > 0;
  return /* @__PURE__ */ jsxDEV(Popover, { children: [
    /* @__PURE__ */ jsxDEV(PopoverTrigger, { asChild: true, children: /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", size: "icon", children: showDot ? /* @__PURE__ */ jsxDEV(Icons.bellDot, { className: "h-6 w-6" }, void 0, false, {
      fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/notification-popover/notification-popover.tsx",
      lineNumber: 45,
      columnNumber: 11
    }, this) : /* @__PURE__ */ jsxDEV(Icons.bell, { className: "h-6 w-6" }, void 0, false, {
      fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/notification-popover/notification-popover.tsx",
      lineNumber: 47,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/notification-popover/notification-popover.tsx",
      lineNumber: 43,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/notification-popover/notification-popover.tsx",
      lineNumber: 42,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(PopoverContent, { className: "relative right-20 w-fit max-w-md", children: /* @__PURE__ */ jsxDEV("div", { className: "", children: /* @__PURE__ */ jsxDEV("div", { className: "", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "p-4", children: /* @__PURE__ */ jsxDEV("h4", { className: "text-lg font-medium leading-none", children: "Notifications" }, void 0, false, {
        fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/notification-popover/notification-popover.tsx",
        lineNumber: 55,
        columnNumber: 15
      }, this) }, void 0, false, {
        fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/notification-popover/notification-popover.tsx",
        lineNumber: 54,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "h-px w-full bg-slate-100" }, void 0, false, {
        fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/notification-popover/notification-popover.tsx",
        lineNumber: 59,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "max-h-[80vh] overflow-y-auto", children: /* @__PURE__ */ jsxDEV("div", { className: "my-2", children: notifications && notifications.map(
        (notification) => /* @__PURE__ */ jsxDEV(
          NotificationCard,
          {
            title: notification.title,
            content: notification.content
          },
          notification.id,
          false,
          {
            fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/notification-popover/notification-popover.tsx",
            lineNumber: 64,
            columnNumber: 17
          },
          this
        )
      ) }, void 0, false, {
        fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/notification-popover/notification-popover.tsx",
        lineNumber: 61,
        columnNumber: 15
      }, this) }, void 0, false, {
        fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/notification-popover/notification-popover.tsx",
        lineNumber: 60,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/notification-popover/notification-popover.tsx",
      lineNumber: 53,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/notification-popover/notification-popover.tsx",
      lineNumber: 52,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/notification-popover/notification-popover.tsx",
      lineNumber: 51,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/notification-popover/notification-popover.tsx",
    lineNumber: 41,
    columnNumber: 5
  }, this);
}
_c2 = NotificationsPopover;
var _c, _c2;
$RefreshReg$(_c, "NotificationCard");
$RefreshReg$(_c2, "NotificationsPopover");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/notification-popover/notification-popover.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
