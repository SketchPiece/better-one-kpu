export { default } from "/src/components/notification-popover/notification-popover.tsx.js";
