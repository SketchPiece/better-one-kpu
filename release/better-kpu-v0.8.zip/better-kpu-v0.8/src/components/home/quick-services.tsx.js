import { createHotContext as __vite__createHotContext } from "/vendor/vite-client.js";import.meta.hot = __vite__createHotContext("/src/components/home/quick-services.tsx.js");import __vite__cjsImport0_react_jsxDevRuntime from "/vendor/.vite-deps-react_jsx-dev-runtime.js__v--752ceaf0.js"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/vendor/react-refresh.js";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/home/quick-services.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import ServiceCardSkeleton from "/src/components/home/service-card-skeleton.tsx.js";
import { useQuickServices } from "/src/hooks/api/use-quick-services.ts.js";
import ServiceCard from "/src/components/home/service-card.tsx.js";
import { resolveImageUrl } from "/src/lib/utils.ts.js";
import { useFavoriteMutation } from "/src/hooks/api/use-favorite-mutation.ts.js";
export default function QuickServices({ filter }) {
  _s();
  const { isLoading, data } = useQuickServices({
    quickFilter: filter || void 0
  });
  const { mutate: updateFavorite } = useFavoriteMutation();
  return /* @__PURE__ */ jsxDEV("div", { className: "my-6 grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3 2xl:grid-cols-4", children: isLoading ? /* @__PURE__ */ jsxDEV(ServiceCardSkeleton, { amount: 8 }, void 0, false, {
    fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/home/quick-services.tsx",
    lineNumber: 22,
    columnNumber: 7
  }, this) : data?.map(
    ({ id, title, description, image, uniqueKey, uid, favorite }) => /* @__PURE__ */ jsxDEV(
      ServiceCard,
      {
        devId: id,
        title,
        image: resolveImageUrl(image),
        description,
        favorite,
        href: `launch-task/all/${uniqueKey}`,
        onFavoriteChange: (favorite2) => updateFavorite({ favorite: favorite2, uid })
      },
      uniqueKey,
      false,
      {
        fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/home/quick-services.tsx",
        lineNumber: 26,
        columnNumber: 9
      },
      this
    )
  ) }, void 0, false, {
    fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/home/quick-services.tsx",
    lineNumber: 20,
    columnNumber: 5
  }, this);
}
_s(QuickServices, "KO65oxfdZ80nFMkhhFSWAlFbO68=", false, function() {
  return [useQuickServices, useFavoriteMutation];
});
_c = QuickServices;
var _c;
$RefreshReg$(_c, "QuickServices");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/home/quick-services.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
