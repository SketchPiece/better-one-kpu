import { createHotContext as __vite__createHotContext } from "/vendor/vite-client.js";import.meta.hot = __vite__createHotContext("/src/components/home/other-services.tsx.js");import __vite__cjsImport0_react_jsxDevRuntime from "/vendor/.vite-deps-react_jsx-dev-runtime.js__v--752ceaf0.js"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/vendor/react-refresh.js";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/home/other-services.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import InfiniteScroll from "/vendor/.vite-deps-react-infinite-scroll-component.js__v--752ceaf0.js";
import ServiceCardSkeleton from "/src/components/home/service-card-skeleton.tsx.js";
import { useServicesInfiniteQuery } from "/src/hooks/api/use-services-infinite-query.ts.js";
import { mapCategoryValueToName } from "/src/lib/categories.ts.js";
import { useQuickServices } from "/src/hooks/api/use-quick-services.ts.js";
import ServiceCard from "/src/components/home/service-card.tsx.js";
import { cn, resolveImageUrl } from "/src/lib/utils.ts.js";
import { useFavoriteMutation } from "/src/hooks/api/use-favorite-mutation.ts.js";
function defineHeading(searchQuery, category) {
  if (searchQuery)
    return `Search Results for "${searchQuery}"`;
  if (category)
    return `${mapCategoryValueToName(category)} Category`;
  return "Other Services";
}
function filterOtherServices(services, ids) {
  return services.filter((service) => !ids.includes(service.id));
}
export default function OtherServices({
  searchQuery,
  category,
  quickFilter
}) {
  _s();
  const {
    data: otherServices,
    fetchNextPage,
    hasNextPage,
    isLoading
  } = useServicesInfiniteQuery({
    searchQuery,
    category
  });
  const { mutate: updateFavorite } = useFavoriteMutation();
  const { dataIds: quickServicesIds } = useQuickServices({
    quickFilter: quickFilter || void 0
  });
  const heading = defineHeading(searchQuery, category || void 0);
  const otherServicesFiltered = filterOtherServices(
    otherServices || [],
    quickServicesIds
  );
  const increaseMargin = quickFilter !== null;
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(
      "h2",
      {
        className: cn(
          "text-3xl font-medium",
          increaseMargin ? "mt-12" : "mt-6"
        ),
        children: heading
      },
      void 0,
      false,
      {
        fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/home/other-services.tsx",
        lineNumber: 60,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { children: isLoading ? /* @__PURE__ */ jsxDEV("div", { className: "my-6 grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3 2xl:grid-cols-4", children: /* @__PURE__ */ jsxDEV(ServiceCardSkeleton, { amount: 16 }, void 0, false, {
      fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/home/other-services.tsx",
      lineNumber: 71,
      columnNumber: 13
    }, this) }, void 0, false, {
      fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/home/other-services.tsx",
      lineNumber: 70,
      columnNumber: 9
    }, this) : /* @__PURE__ */ jsxDEV(
      InfiniteScroll,
      {
        className: "relative my-6 grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3 2xl:grid-cols-4",
        dataLength: otherServicesFiltered.length,
        next: fetchNextPage,
        hasMore: hasNextPage,
        loader: /* @__PURE__ */ jsxDEV(ServiceCardSkeleton, { amount: 8 }, void 0, false, {
          fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/home/other-services.tsx",
          lineNumber: 79,
          columnNumber: 19
        }, this),
        children: otherServicesFiltered.map(
          ({ id, title, description, image, uniqueKey, uid, favorite }) => /* @__PURE__ */ jsxDEV(
            ServiceCard,
            {
              devId: id,
              title,
              image: resolveImageUrl(image),
              description,
              favorite,
              href: `launch-task/all/${uniqueKey}`,
              onFavoriteChange: (favorite2) => updateFavorite({ favorite: favorite2, uid })
            },
            uniqueKey,
            false,
            {
              fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/home/other-services.tsx",
              lineNumber: 83,
              columnNumber: 13
            },
            this
          )
        )
      },
      void 0,
      false,
      {
        fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/home/other-services.tsx",
        lineNumber: 74,
        columnNumber: 9
      },
      this
    ) }, void 0, false, {
      fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/home/other-services.tsx",
      lineNumber: 68,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/home/other-services.tsx",
    lineNumber: 59,
    columnNumber: 5
  }, this);
}
_s(OtherServices, "FlZITcvBJ3/SmhscnkhufQK9oBY=", false, function() {
  return [useServicesInfiniteQuery, useFavoriteMutation, useQuickServices];
});
_c = OtherServices;
var _c;
$RefreshReg$(_c, "OtherServices");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/home/other-services.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
