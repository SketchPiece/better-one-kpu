import { createHotContext as __vite__createHotContext } from "/vendor/vite-client.js";import.meta.hot = __vite__createHotContext("/src/components/home/quick-filters.tsx.js");import __vite__cjsImport0_react_jsxDevRuntime from "/vendor/.vite-deps-react_jsx-dev-runtime.js__v--752ceaf0.js"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/vendor/react-refresh.js";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/home/quick-filters.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/vendor/.vite-deps-react.js__v--752ceaf0.js"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import { Icons } from "/src/components/icons.tsx.js";
import { cn } from "/src/lib/utils.ts.js";
import SimpleTooltip from "/src/components/ui/simple-tooltip.tsx.js";
import { useUserProfileQuery } from "/src/hooks/api/use-user-profile-query.ts.js";
export default function QuickFilters({
  value,
  onChange,
  authorized
}) {
  _s();
  const { data: userProfile, isLoading } = useUserProfileQuery();
  const [selectedValue, setSelectedValue] = useState(
    value || null
  );
  useEffect(() => {
    const isNotEssentials = value !== null && value !== "essentials";
    const isNotAuthorized = !isLoading && !userProfile;
    if (isNotEssentials && isNotAuthorized) {
      setSelectedValue("essentials");
      onChange?.("essentials");
    }
  }, [userProfile, isLoading, selectedValue]);
  const handleClick = (value2) => {
    setSelectedValue(value2);
    onChange?.(value2);
  };
  useEffect(() => {
    if (value !== selectedValue && value !== void 0)
      setSelectedValue(value);
  }, [value, selectedValue]);
  return /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4", children: [
    /* @__PURE__ */ jsxDEV(
      "button",
      {
        type: "button",
        onClick: () => handleClick("essentials"),
        className: cn(
          "dark:ring-offset-dark-background inline-flex items-center justify-center whitespace-nowrap rounded-full border border-[#EFEFEF] px-4 py-2.5 font-medium transition-all focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2 disabled:opacity-50",
          selectedValue === "essentials" ? "border-primary bg-primary text-white" : "hover:bg-[#F5F5F5] dark:border-[#3D3D3D] dark:hover:bg-[#1E1E1E]"
        ),
        children: [
          /* @__PURE__ */ jsxDEV(Icons.circleCheck, { className: "mr-2" }, void 0, false, {
            fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/home/quick-filters.tsx",
            lineNumber: 59,
            columnNumber: 9
          }, this),
          "Essentials"
        ]
      },
      void 0,
      true,
      {
        fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/home/quick-filters.tsx",
        lineNumber: 49,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(SimpleTooltip, { content: "Sign in to view favorites", disabled: authorized, children: /* @__PURE__ */ jsxDEV(
      "button",
      {
        type: "button",
        disabled: !authorized,
        onClick: () => authorized && handleClick("favorites"),
        className: cn(
          "dark:ring-offset-dark-background inline-flex items-center justify-center whitespace-nowrap rounded-full border border-[#EFEFEF] px-4 py-2.5 font-medium transition-all focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2 disabled:opacity-50",
          selectedValue === "favorites" ? "border-primary bg-primary text-white" : "hover:bg-[#F5F5F5] dark:border-[#3D3D3D] dark:hover:bg-[#1E1E1E]"
        ),
        children: [
          /* @__PURE__ */ jsxDEV(Icons.starOutline, { className: "mr-2" }, void 0, false, {
            fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/home/quick-filters.tsx",
            lineNumber: 74,
            columnNumber: 11
          }, this),
          "Favorites"
        ]
      },
      void 0,
      true,
      {
        fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/home/quick-filters.tsx",
        lineNumber: 63,
        columnNumber: 9
      },
      this
    ) }, void 0, false, {
      fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/home/quick-filters.tsx",
      lineNumber: 62,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(SimpleTooltip, { content: "Sign in to view recents", disabled: authorized, children: /* @__PURE__ */ jsxDEV(
      "button",
      {
        type: "button",
        disabled: !authorized,
        onClick: () => authorized && handleClick("recents"),
        className: cn(
          "dark:ring-offset-dark-background inline-flex items-center justify-center whitespace-nowrap rounded-full border border-[#EFEFEF] px-4 py-2.5 font-medium transition-all focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2 disabled:opacity-50",
          selectedValue === "recents" ? "border-primary bg-primary text-white" : "hover:bg-[#F5F5F5] dark:border-[#3D3D3D] dark:hover:bg-[#1E1E1E]"
        ),
        children: [
          /* @__PURE__ */ jsxDEV(Icons.history, { className: "mr-2" }, void 0, false, {
            fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/home/quick-filters.tsx",
            lineNumber: 90,
            columnNumber: 11
          }, this),
          "Recents"
        ]
      },
      void 0,
      true,
      {
        fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/home/quick-filters.tsx",
        lineNumber: 79,
        columnNumber: 9
      },
      this
    ) }, void 0, false, {
      fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/home/quick-filters.tsx",
      lineNumber: 78,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/home/quick-filters.tsx",
    lineNumber: 48,
    columnNumber: 5
  }, this);
}
_s(QuickFilters, "h4/J3AJKV4qjYfyAk3COrcBL7Wc=", false, function() {
  return [useUserProfileQuery];
});
_c = QuickFilters;
var _c;
$RefreshReg$(_c, "QuickFilters");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/home/quick-filters.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
