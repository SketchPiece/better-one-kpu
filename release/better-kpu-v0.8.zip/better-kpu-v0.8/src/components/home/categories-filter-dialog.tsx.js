import { createHotContext as __vite__createHotContext } from "/vendor/vite-client.js";import.meta.hot = __vite__createHotContext("/src/components/home/categories-filter-dialog.tsx.js");import __vite__cjsImport0_react_jsxDevRuntime from "/vendor/.vite-deps-react_jsx-dev-runtime.js__v--752ceaf0.js"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/vendor/react-refresh.js";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/home/categories-filter-dialog.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import categories from "/src/lib/categories.ts.js";
import { Icons } from "/src/components/icons.tsx.js";
import { Button } from "/src/components/ui/button.tsx.js";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger
} from "/src/components/ui/dialog.tsx.js";
import __vite__cjsImport7_react from "/vendor/.vite-deps-react.js__v--752ceaf0.js"; const useEffect = __vite__cjsImport7_react["useEffect"]; const useState = __vite__cjsImport7_react["useState"];
function CategoryButton({ name, icon, items, ...props }) {
  return /* @__PURE__ */ jsxDEV(
    "button",
    {
      className: "flex items-center rounded-lg p-2 transition-all hover:bg-[#F9F9F9] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2",
      ...props,
      children: [
        /* @__PURE__ */ jsxDEV("span", { className: "flex items-center gap-2", children: [
          icon,
          /* @__PURE__ */ jsxDEV("span", { className: "ml-2", children: name }, void 0, false, {
            fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/home/categories-filter-dialog.tsx",
            lineNumber: 29,
            columnNumber: 9
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/home/categories-filter-dialog.tsx",
          lineNumber: 27,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "ml-auto", children: items }, void 0, false, {
          fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/home/categories-filter-dialog.tsx",
          lineNumber: 31,
          columnNumber: 7
        }, this)
      ]
    },
    void 0,
    true,
    {
      fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/home/categories-filter-dialog.tsx",
      lineNumber: 23,
      columnNumber: 5
    },
    this
  );
}
_c = CategoryButton;
export default function CategoriesFilterDialog({
  onChange,
  value
}) {
  _s();
  const [isOpen, setIsOpen] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState();
  const handleCategorySelect = (category) => {
    setSelectedCategory(category);
    setIsOpen(false);
    onChange?.(category.value);
  };
  const handleCategoryClear = (e) => {
    e.stopPropagation();
    setSelectedCategory(void 0);
    onChange?.(null);
  };
  useEffect(() => {
    if (value !== selectedCategory && value !== void 0) {
      if (value === null)
        setSelectedCategory(void 0);
      else
        setSelectedCategory(categories.find((c) => c.value === value));
    }
  }, [value, selectedCategory]);
  return /* @__PURE__ */ jsxDEV(Dialog, { open: isOpen, onOpenChange: setIsOpen, children: [
    /* @__PURE__ */ jsxDEV(DialogTrigger, { asChild: true, children: selectedCategory ? /* @__PURE__ */ jsxDEV(Button, { variant: "default", size: "lg", children: [
      /* @__PURE__ */ jsxDEV(selectedCategory.icon, { className: "mr-2" }, void 0, false, {
        fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/home/categories-filter-dialog.tsx",
        lineNumber: 72,
        columnNumber: 13
      }, this),
      " ",
      selectedCategory.name,
      /* @__PURE__ */ jsxDEV(
        Icons.darkClose,
        {
          className: "ml-2 h-5 w-5 hover:opacity-80",
          onClick: handleCategoryClear
        },
        void 0,
        false,
        {
          fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/home/categories-filter-dialog.tsx",
          lineNumber: 73,
          columnNumber: 13
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/home/categories-filter-dialog.tsx",
      lineNumber: 71,
      columnNumber: 9
    }, this) : /* @__PURE__ */ jsxDEV(Button, { variant: "secondary", size: "lg", children: [
      /* @__PURE__ */ jsxDEV(Icons.filters, { className: "mr-2" }, void 0, false, {
        fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/home/categories-filter-dialog.tsx",
        lineNumber: 80,
        columnNumber: 13
      }, this),
      " Filters"
    ] }, void 0, true, {
      fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/home/categories-filter-dialog.tsx",
      lineNumber: 79,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/home/categories-filter-dialog.tsx",
      lineNumber: 69,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(DialogContent, { className: "max-w-4xl", children: [
      /* @__PURE__ */ jsxDEV(DialogHeader, { children: [
        /* @__PURE__ */ jsxDEV(DialogTitle, { children: "Categories" }, void 0, false, {
          fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/home/categories-filter-dialog.tsx",
          lineNumber: 86,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(DialogDescription, { children: "Select category to filter university services" }, void 0, false, {
          fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/home/categories-filter-dialog.tsx",
          lineNumber: 87,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/home/categories-filter-dialog.tsx",
        lineNumber: 85,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-3 gap-x-4 gap-y-2", children: categories.map(
        (category) => /* @__PURE__ */ jsxDEV(
          CategoryButton,
          {
            name: category.name,
            icon: /* @__PURE__ */ jsxDEV(category.icon, {}, void 0, false, {
              fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/home/categories-filter-dialog.tsx",
              lineNumber: 96,
              columnNumber: 19
            }, this),
            items: category.items,
            onClick: () => handleCategorySelect(category)
          },
          category.name,
          false,
          {
            fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/home/categories-filter-dialog.tsx",
            lineNumber: 93,
            columnNumber: 11
          },
          this
        )
      ) }, void 0, false, {
        fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/home/categories-filter-dialog.tsx",
        lineNumber: 91,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/home/categories-filter-dialog.tsx",
      lineNumber: 84,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/home/categories-filter-dialog.tsx",
    lineNumber: 68,
    columnNumber: 5
  }, this);
}
_s(CategoriesFilterDialog, "17TWSNAzsS12skINvrv3oge08l8=");
_c2 = CategoriesFilterDialog;
var _c, _c2;
$RefreshReg$(_c, "CategoryButton");
$RefreshReg$(_c2, "CategoriesFilterDialog");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/home/categories-filter-dialog.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
