import { createHotContext as __vite__createHotContext } from "/vendor/vite-client.js";import.meta.hot = __vite__createHotContext("/src/components/home/service-card.tsx.js");import __vite__cjsImport0_react_jsxDevRuntime from "/vendor/.vite-deps-react_jsx-dev-runtime.js__v--752ceaf0.js"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/vendor/react-refresh.js";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/home/service-card.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/vendor/.vite-deps-react.js__v--752ceaf0.js"; const useState = __vite__cjsImport3_react["useState"];
import { Icons } from "/src/components/icons.tsx.js";
import { Button } from "/src/components/ui/button.tsx.js";
import { cn } from "/src/lib/utils.ts.js";
import { useUserProfileQuery } from "/src/hooks/api/use-user-profile-query.ts.js";
export default function ServiceCard({
  devId,
  title,
  description,
  image,
  favorite,
  onFavoriteChange,
  ...props
}) {
  _s();
  const { data: userProfile } = useUserProfileQuery();
  const [isFavorite, setIsFavorite] = useState(favorite);
  const handleFavoriteChange = (e) => {
    e.stopPropagation();
    e.preventDefault();
    setIsFavorite(!isFavorite);
    onFavoriteChange?.(!isFavorite);
  };
  return /* @__PURE__ */ jsxDEV(
    "a",
    {
      className: "dark:ring-offset-dark-background group relative flex items-center justify-center gap-4 rounded-xl px-8 py-6 transition-all hover:bg-[#F9F9F9] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2 dark:hover:bg-[#2E2E2E]",
      ...props,
      children: [
        /* @__PURE__ */ jsxDEV(
          "img",
          {
            src: image,
            alt: title,
            className: "h-20 w-20 rounded-full border border-[#F0F0F0] object-cover dark:border-[#2E2E2E]"
          },
          void 0,
          false,
          {
            fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/home/service-card.tsx",
            lineNumber: 41,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-1 flex-col", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-medium", children: title }, void 0, false, {
            fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/home/service-card.tsx",
            lineNumber: 47,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-sm", children: description }, void 0, false, {
            fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/home/service-card.tsx",
            lineNumber: 48,
            columnNumber: 9
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/home/service-card.tsx",
          lineNumber: 46,
          columnNumber: 7
        }, this),
        userProfile && /* @__PURE__ */ jsxDEV(
          Button,
          {
            tabIndex: -1,
            variant: "ghost",
            size: "icon",
            className: cn(
              "absolute right-3 top-3 opacity-0 transition-all group-hover:opacity-100",
              isFavorite && "opacity-100"
            ),
            onClick: handleFavoriteChange,
            children: isFavorite ? /* @__PURE__ */ jsxDEV(Icons.star, { className: "h-5 w-5 text-yellow-400" }, void 0, false, {
              fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/home/service-card.tsx",
              lineNumber: 62,
              columnNumber: 9
            }, this) : /* @__PURE__ */ jsxDEV(Icons.starOutline, { className: "h-5 w-5" }, void 0, false, {
              fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/home/service-card.tsx",
              lineNumber: 64,
              columnNumber: 9
            }, this)
          },
          void 0,
          false,
          {
            fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/home/service-card.tsx",
            lineNumber: 51,
            columnNumber: 7
          },
          this
        )
      ]
    },
    void 0,
    true,
    {
      fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/home/service-card.tsx",
      lineNumber: 36,
      columnNumber: 5
    },
    this
  );
}
_s(ServiceCard, "qRVilhP7+7qSSksdvPlvMBclpHg=", false, function() {
  return [useUserProfileQuery];
});
_c = ServiceCard;
var _c;
$RefreshReg$(_c, "ServiceCard");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/home/service-card.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
