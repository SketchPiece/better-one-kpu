import __vite__cjsImport0_react from "/vendor/.vite-deps-react.js__v--752ceaf0.js"; const useCallback = __vite__cjsImport0_react["useCallback"]; const useReducer = __vite__cjsImport0_react["useReducer"];
const reducer = (defaultView) => (state, action) => {
  switch (action.type) {
    case "SET_QUICK_FILTER":
      return {
        ...state,
        selectedQuickFilter: action.value,
        selectedCategory: null,
        searchQuery: ""
      };
    case "SET_CATEGORY":
      return {
        ...state,
        selectedCategory: action.value,
        selectedQuickFilter: action.value === null ? defaultView : null,
        searchQuery: ""
      };
    case "SET_SEARCH_QUERY":
      return {
        ...state,
        searchQuery: action.query,
        selectedQuickFilter: action.query === "" ? defaultView : null,
        selectedCategory: null
      };
    default:
      return state;
  }
};
const initialState = (defaultView) => ({
  searchQuery: "",
  selectedQuickFilter: defaultView,
  selectedCategory: null
});
export default function useFilterState({
  defaultQuickFilter
}) {
  const [state, dispatch] = useReducer(
    reducer(defaultQuickFilter),
    initialState(defaultQuickFilter)
  );
  const handleQuickFilterChange = useCallback(
    (value) => {
      dispatch({ type: "SET_QUICK_FILTER", value });
    },
    [dispatch]
  );
  const handleCategoryChange = useCallback(
    (value) => {
      dispatch({ type: "SET_CATEGORY", value });
    },
    [dispatch]
  );
  const handleSearchQueryChange = useCallback(
    (query) => {
      dispatch({ type: "SET_SEARCH_QUERY", query });
    },
    [dispatch]
  );
  return {
    state,
    handleQuickFilterChange,
    handleCategoryChange,
    handleSearchQueryChange
  };
}
