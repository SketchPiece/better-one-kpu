import { createHotContext as __vite__createHotContext } from "/vendor/vite-client.js";import.meta.hot = __vite__createHotContext("/src/components/scroll-to-top-button.tsx.js");import __vite__cjsImport0_react_jsxDevRuntime from "/vendor/.vite-deps-react_jsx-dev-runtime.js__v--752ceaf0.js"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/vendor/react-refresh.js";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/scroll-to-top-button.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/vendor/.vite-deps-react.js__v--752ceaf0.js"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import { AnimatePresence, motion } from "/vendor/.vite-deps-framer-motion.js__v--752ceaf0.js";
import { Icons } from "/src/components/icons.tsx.js";
function ScrollToTopButton() {
  _s();
  const [isVisible, setIsVisible] = useState(false);
  function toggleVisibility() {
    if (document.documentElement.scrollTop > 300 || document.body.scrollTop > 300) {
      setIsVisible(true);
    } else {
      setIsVisible(false);
    }
  }
  function scrollToTop() {
    window.scrollTo({
      top: 0,
      behavior: "smooth"
    });
  }
  useEffect(() => {
    window.addEventListener("scroll", toggleVisibility);
    return () => {
      window.removeEventListener("scroll", toggleVisibility);
    };
  }, []);
  return /* @__PURE__ */ jsxDEV("div", { className: "fixed bottom-4 right-4", children: /* @__PURE__ */ jsxDEV(AnimatePresence, { children: isVisible && /* @__PURE__ */ jsxDEV(
    motion.button,
    {
      onClick: scrollToTop,
      className: "rounded-full border bg-white p-2.5 text-black shadow-lg transition-colors hover:bg-gray-100",
      whileTap: { scale: 0.95 },
      initial: { opacity: 0, y: 50 },
      animate: { opacity: 1, y: 0 },
      exit: { opacity: 0, y: 50 },
      transition: { duration: 0.2 },
      children: /* @__PURE__ */ jsxDEV(Icons.arrowUp, { className: "h-6 w-6" }, void 0, false, {
        fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/scroll-to-top-button.tsx",
        lineNumber: 46,
        columnNumber: 13
      }, this)
    },
    void 0,
    false,
    {
      fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/scroll-to-top-button.tsx",
      lineNumber: 37,
      columnNumber: 9
    },
    this
  ) }, void 0, false, {
    fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/scroll-to-top-button.tsx",
    lineNumber: 35,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/scroll-to-top-button.tsx",
    lineNumber: 34,
    columnNumber: 5
  }, this);
}
_s(ScrollToTopButton, "J3yJOyGdBT4L7hs1p1XQYVGMdrY=");
_c = ScrollToTopButton;
export default ScrollToTopButton;
var _c;
$RefreshReg$(_c, "ScrollToTopButton");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/scroll-to-top-button.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
