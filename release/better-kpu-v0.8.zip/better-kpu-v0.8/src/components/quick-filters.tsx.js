import { createHotContext as __vite__createHotContext } from "/vendor/vite-client.js";import.meta.hot = __vite__createHotContext("/src/components/quick-filters.tsx.js");import __vite__cjsImport0_react_jsxDevRuntime from "/vendor/.vite-deps-react_jsx-dev-runtime.js__v--fbc305df.js"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/vendor/react-refresh.js";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/quick-filters.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/vendor/.vite-deps-react.js__v--fbc305df.js"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import { Icons } from "/src/components/icons.tsx.js";
import { cn } from "/src/lib/utils.ts.js";
export default function QuickFilters({ value, onChange }) {
  _s();
  const [selectedValue, setSelectedValue] = useState(
    value || "essentials"
  );
  const handleClick = (value2) => {
    setSelectedValue(value2);
    onChange?.(value2);
  };
  useEffect(() => {
    if (value !== selectedValue && value !== void 0)
      setSelectedValue(value);
  }, [value, selectedValue]);
  return /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4", children: [
    /* @__PURE__ */ jsxDEV(
      "button",
      {
        type: "button",
        onClick: () => handleClick("essentials"),
        className: cn(
          "inline-flex items-center justify-center whitespace-nowrap rounded-full border border-[#EFEFEF] px-4 py-2.5 font-medium transition-all focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2",
          selectedValue === "essentials" && "border-primary bg-primary text-white"
        ),
        children: [
          /* @__PURE__ */ jsxDEV(Icons.circleCheck, { className: "mr-2" }, void 0, false, {
            fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/quick-filters.tsx",
            lineNumber: 37,
            columnNumber: 9
          }, this),
          "Essentials"
        ]
      },
      void 0,
      true,
      {
        fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/quick-filters.tsx",
        lineNumber: 28,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      "button",
      {
        type: "button",
        onClick: () => handleClick("favorites"),
        className: cn(
          "inline-flex items-center justify-center whitespace-nowrap rounded-full border border-[#EFEFEF] px-4 py-2.5 font-medium transition-all focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2",
          selectedValue === "favorites" && "border-primary bg-primary text-white"
        ),
        children: [
          /* @__PURE__ */ jsxDEV(Icons.star, { className: "mr-2" }, void 0, false, {
            fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/quick-filters.tsx",
            lineNumber: 49,
            columnNumber: 9
          }, this),
          "Favorites"
        ]
      },
      void 0,
      true,
      {
        fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/quick-filters.tsx",
        lineNumber: 40,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      "button",
      {
        type: "button",
        onClick: () => handleClick("recent"),
        className: cn(
          "inline-flex items-center justify-center whitespace-nowrap rounded-full border border-[#EFEFEF] px-4 py-2.5 font-medium transition-all focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2",
          selectedValue === "recent" && "border-primary bg-primary text-white"
        ),
        children: [
          /* @__PURE__ */ jsxDEV(Icons.history, { className: "mr-2" }, void 0, false, {
            fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/quick-filters.tsx",
            lineNumber: 60,
            columnNumber: 9
          }, this),
          "Recent"
        ]
      },
      void 0,
      true,
      {
        fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/quick-filters.tsx",
        lineNumber: 52,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/quick-filters.tsx",
    lineNumber: 27,
    columnNumber: 5
  }, this);
}
_s(QuickFilters, "3/O3w+MUom7DeOUJgtcBe+iem9k=");
_c = QuickFilters;
var _c;
$RefreshReg$(_c, "QuickFilters");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/quick-filters.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
