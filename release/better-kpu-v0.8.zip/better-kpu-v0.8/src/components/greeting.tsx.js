import { createHotContext as __vite__createHotContext } from "/vendor/vite-client.js";import.meta.hot = __vite__createHotContext("/src/components/greeting.tsx.js");import __vite__cjsImport0_react_jsxDevRuntime from "/vendor/.vite-deps-react_jsx-dev-runtime.js__v--fbc305df.js"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/vendor/react-refresh.js";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/greeting.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/vendor/.vite-deps-react.js__v--fbc305df.js"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
function defineGreeting(name) {
  const hours = (/* @__PURE__ */ new Date()).getHours();
  let greet;
  if (hours < 12) {
    greet = `Good morning, ${name}`;
  } else if (hours < 18) {
    greet = `Good afternoon, ${name}`;
  } else {
    greet = `Good evening, ${name}`;
  }
  return greet;
}
function Greeting({ name }) {
  _s();
  const [greeting, setGreeting] = useState("");
  useEffect(() => {
    setGreeting(defineGreeting(name));
  }, [name]);
  return /* @__PURE__ */ jsxDEV("h1", { className: "text-4xl font-medium", children: greeting }, void 0, false, {
    fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/greeting.tsx",
    lineNumber: 29,
    columnNumber: 10
  }, this);
}
_s(Greeting, "sRGVxs/uAqyufEwh9BD66JifNMQ=");
_c = Greeting;
export default Greeting;
var _c;
$RefreshReg$(_c, "Greeting");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/components/greeting.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
