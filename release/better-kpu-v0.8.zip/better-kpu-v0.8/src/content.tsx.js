import __vite__cjsImport0_react_jsxDevRuntime from "/vendor/.vite-deps-react_jsx-dev-runtime.js__v--752ceaf0.js"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import __vite__cjsImport1_react from "/vendor/.vite-deps-react.js__v--752ceaf0.js"; const React = __vite__cjsImport1_react.__esModule ? __vite__cjsImport1_react.default : __vite__cjsImport1_react;
import __vite__cjsImport2_reactDom_client from "/vendor/.vite-deps-react-dom_client.js__v--752ceaf0.js"; const ReactDOM = __vite__cjsImport2_reactDom_client.__esModule ? __vite__cjsImport2_reactDom_client.default : __vite__cjsImport2_reactDom_client;
import App from "/src/app.tsx.js";
import "/src/global.css.js";
const injectedBody = `
<div id="root"></div>
<script type="module" src="/src/main.tsx"><\/script>
`;
document.querySelectorAll('link[rel="stylesheet"]').forEach((link) => link.remove());
document.body.innerHTML = injectedBody;
const root = document.getElementById("root");
ReactDOM.createRoot(root).render(
  /* @__PURE__ */ jsxDEV(React.StrictMode, { children: /* @__PURE__ */ jsxDEV(App, {}, void 0, false, {
    fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/content.tsx",
    lineNumber: 21,
    columnNumber: 5
  }, this) }, void 0, false, {
    fileName: "/Users/sketchpiece/Documents/hacking/web/next-one-kpu/src/content.tsx",
    lineNumber: 20,
    columnNumber: 3
  }, this)
);
